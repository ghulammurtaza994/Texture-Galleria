/**
 * Textures Galleria — full-stack server
 * Pure Node.js (no external dependencies) so it runs anywhere Node runs,
 * with zero `npm install` required.
 *
 * Run:   node server.js
 * Site:  http://localhost:3000
 * Admin: http://localhost:3000/admin.html  (passcode set below)
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const url = require('url');

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'change-this-passcode';

const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const PORTFOLIO_FILE = path.join(DATA_DIR, 'portfolio.json');

// ---------- tiny helpers ----------

function readJSON(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return fallback;
  }
}

function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json', ...headers });
  res.end(JSON.stringify(body));
}

function sendFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const types = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
  };
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 1e6) req.destroy(); // 1MB safety cap
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function isAdmin(req, query) {
  const headerKey = req.headers['x-admin-key'];
  return headerKey === ADMIN_KEY || query.key === ADMIN_KEY;
}

// Very small on-topic validation — required fields only.
function validateOrder(o) {
  const errors = [];
  if (!o.name || !o.name.trim()) errors.push('Name is required.');
  if (!o.phone || !o.phone.trim()) errors.push('Phone number is required.');
  if (!o.serviceType) errors.push('Please select a service type.');
  if (!o.details || !o.details.trim()) errors.push('Please add a few details about the order.');
  return errors;
}

// ---------- request handler ----------

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = decodeURIComponent(parsed.pathname);
  const query = parsed.query;

  // ---- API: portfolio (public) ----
  if (pathname === '/api/portfolio' && req.method === 'GET') {
    const portfolio = readJSON(PORTFOLIO_FILE, []);
    return send(res, 200, portfolio);
  }

  // ---- API: submit a new order (public) ----
  if (pathname === '/api/orders' && req.method === 'POST') {
    try {
      const body = await parseBody(req);
      const errors = validateOrder(body);
      if (errors.length) return send(res, 400, { ok: false, errors });

      const orders = readJSON(ORDERS_FILE, []);
      const order = {
        id: crypto.randomUUID(),
        name: body.name.trim(),
        phone: body.phone.trim(),
        email: (body.email || '').trim(),
        serviceType: body.serviceType,
        space: (body.space || '').trim(),
        preferredMaterial: body.preferredMaterial || '',
        budget: body.budget || '',
        details: body.details.trim(),
        status: 'New',
        createdAt: new Date().toISOString(),
      };
      orders.unshift(order);
      writeJSON(ORDERS_FILE, orders);
      return send(res, 201, { ok: true, message: 'Order received. We will contact you shortly.', id: order.id });
    } catch (e) {
      return send(res, 400, { ok: false, errors: ['Could not read the submitted form.'] });
    }
  }

  // ---- API: list orders (admin only) ----
  if (pathname === '/api/orders' && req.method === 'GET') {
    if (!isAdmin(req, query)) return send(res, 401, { ok: false, error: 'Unauthorized' });
    const orders = readJSON(ORDERS_FILE, []);
    return send(res, 200, orders);
  }

  // ---- API: update order status (admin only) ----
  const statusMatch = pathname.match(/^\/api\/orders\/([^/]+)\/status$/);
  if (statusMatch && req.method === 'POST') {
    if (!isAdmin(req, query)) return send(res, 401, { ok: false, error: 'Unauthorized' });
    try {
      const body = await parseBody(req);
      const allowed = ['New', 'Approved', 'In Progress', 'Completed', 'Cancelled'];
      if (!allowed.includes(body.status)) return send(res, 400, { ok: false, error: 'Invalid status' });

      const orders = readJSON(ORDERS_FILE, []);
      const idx = orders.findIndex((o) => o.id === statusMatch[1]);
      if (idx === -1) return send(res, 404, { ok: false, error: 'Order not found' });

      orders[idx].status = body.status;
      writeJSON(ORDERS_FILE, orders);
      return send(res, 200, { ok: true, order: orders[idx] });
    } catch (e) {
      return send(res, 400, { ok: false, error: 'Bad request' });
    }
  }

  // ---- API: add a completed order to the public portfolio (admin only) ----
  if (pathname === '/api/portfolio' && req.method === 'POST') {
    if (!isAdmin(req, query)) return send(res, 401, { ok: false, error: 'Unauthorized' });
    try {
      const body = await parseBody(req);
      if (!body.title || !body.description || !body.material) {
        return send(res, 400, { ok: false, error: 'title, description and material are required.' });
      }
      const portfolio = readJSON(PORTFOLIO_FILE, []);
      const item = {
        id: crypto.randomUUID(),
        title: body.title,
        description: body.description,
        material: body.material, // 'wood' | 'velvet' | 'jute' | 'mixed'
        location: body.location || '',
        addedAt: new Date().toISOString(),
      };
      portfolio.unshift(item);
      writeJSON(PORTFOLIO_FILE, portfolio);
      return send(res, 201, { ok: true, item });
    } catch (e) {
      return send(res, 400, { ok: false, error: 'Bad request' });
    }
  }

  // ---- static files ----
  let filePath = pathname === '/' ? '/index.html' : pathname;
  filePath = path.join(PUBLIC_DIR, filePath);

  // prevent path traversal outside /public
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }

  fs.stat(filePath, (err, stat) => {
    if (!err && stat.isFile()) {
      return sendFile(res, filePath);
    }
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found');
  });
});

server.listen(PORT, () => {
  console.log(`Textures Galleria running at http://localhost:${PORT}`);
  console.log(`Admin panel:            http://localhost:${PORT}/admin.html`);
  console.log(`Admin passcode (change via ADMIN_KEY env var): ${ADMIN_KEY}`);
});
